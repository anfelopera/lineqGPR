#ifndef _tmg_RTMG_H
#define _tmg_RTMG_H

#include <RcppEigen.h>

RcppExport SEXP rtmg(SEXP n_, SEXP seed_, SEXP initial_,  SEXP numlin_, SEXP F_, SEXP g_, SEXP numquad_ , SEXP quadratics_ ) ;



#endif
